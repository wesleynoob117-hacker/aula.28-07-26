#Encapsulamento
#Oq é?
#Imagine uma conta bancaria e um saldo de 1000000 de reais
#Por acaso é possivel alterar esse valor de qualquer forma ou
#Em qualquer parte do sistema?
#

class contabancaria:
    def __init__ (self, titular, saldo):
        self.titular = titular
        self.__saldo = saldo
        #__ indica que o atributo é private
    def depositar(self, valor):
        if valor > 0:
            self.__saldo += valor
            print("Depósito realizado.")
        else:
            print("Valor inválido.")
        
    def sacarvalor(self, valor):
        if valor <= self.__saldo:
            self.__saldo -= valor
            print("Saque realizado!")
        else:
            print("Saldo insuficiente.")
        
    def mostrar_saldo(self):
        print(f"Saldo atual: R$ {self.__saldo:.2f}")
        
conta1 = contabancaria("EU",1000)
conta1.mostrar_saldo()
print()
conta1.depositar(200)
print()
conta1.mostrar_saldo()
print()
conta1.sacarvalor(200)
print()
conta1.mostrar_saldo()

conta1.__saldo = 10000
print("_")
conta1.mostrar_saldo