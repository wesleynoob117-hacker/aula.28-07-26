#Polimofismo
#Objetos Diferentes podem responder ao mesmo método
#Todos possuem o método: Falar
#Mas cada um fala diferente>Exemplo: CACHORROS

class cachorro:
    #def __init__(self):
    def falar(self):
        print("AU AU")
        
class gato:
     def falar(self):
            print("MIAU MIAU")
            
class vaca:
     def falar(self):
            print("MUU MUU")
    
def emitir_som(animal):
    animal.falar()
    
cachorro = cachorro()
gato = gato()
vaca = vaca()

emitir_som(cachorro)
emitir_som(gato)
emitir_som(vaca)
