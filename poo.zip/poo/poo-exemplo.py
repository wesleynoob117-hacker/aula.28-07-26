#classe em python
class Carro:#É o modelo de todos os caarros do meu sistema.
    #método construtor
    def __init__(self, marca, modelo, ano):
        #def init é o método construtor, será executado sempre
        #na criação de objeto 
        self.marca = marca
        self.modelo = modelo
        self.ano = ano
        
    #método da classe
    def exibir_dados(self):
        print("=== Dados do Carro ===")
        print(f"Marca:{self.marca}")
        print(f"Modelo:{self.modelo}")
        print(f"ano:{self.ano}")
        
#criando objetos
carro1 = Carro("Toyota","Supra",1993)
carro2 = Carro("Nissan","GT-R R34",1999)
#chamada do objeto e método
carro1.exibir_dados()
print("-"*30)
carro2.exibir_dados() 