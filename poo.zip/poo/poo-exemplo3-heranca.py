#Herança
#Suponha que existam vários veículos
#Todos possuem: rodas, acelerar, frear
#Logo, não faz sentido repetir código.
#Podemos criar uma classe geral
#Dps fazemos outas classes herdarem dela.
#Pai

class veiculo:
    def __init__(self, rodas):
        self.rodas = rodas
    def acelerar(self):
        print(f"O {self.modelo} de {self.rodas} rodas acelerou!")
#Filho
#O carro herda tudo da classe veículo
class carro(veiculo):#É obrigatório a declaração class filha(nome da classe)
#heranca multipla> class carroeletrico(carro, vaiculo, ... ,)    
    def __init__(self, marca, modelo):
        
        super().__init__(4)#Executa o construtor da classe pai
        #atributo da classr Pai
        self.marca = marca
        self.modelo = modelo
        print(f"Criando um carro{self.marca} com {self.rodas} rodas.")
        
carro1 = carro("Toyota", "Supra")
print()
carro1.acelerar()
