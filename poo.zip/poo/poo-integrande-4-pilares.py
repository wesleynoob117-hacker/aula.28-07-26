#Integrando os 4 pilares do poo

class Funcionario:
    def __init__(self, nome, salario):
        self.nome = nome
        self.__salario = salario
    def mostrar_dados(self):
        print(f"Funcionario: {self.nome}")
        
    def calcular_bonus(self):
        return self.__salario *0.10 + self.__salario
    
class Gerente(Funcionario):
    def calcular_bonus(self):
        return 5000
    
class desenvolvedor(Funcionario):
    def calcular_bonus(self):
        return 2000

gerente = Gerente("carlos", 10000)
dev = desenvolvedor("ana", 8000)

gerente.mostrar_dados()
print("Bonus:", gerente.calcular_bonus())
print("-"*30)
dev.mostrar_dados()
print("Bonus:", dev.calcular_bonus())

"""
Conceito---------
Classe--------- Func, Ger, Dev
Objeto--------- Gerente1, Dev1
Metodo--------- Mostrar_Dados()
Atributo--------- Nome, __Salrio
Encapsulamento--------- __Salario
Heranca--------- Gerente(Funcionario)
Polimofismo--------- Calcular_Bonus() --Diferente em cada classe
        
""" 